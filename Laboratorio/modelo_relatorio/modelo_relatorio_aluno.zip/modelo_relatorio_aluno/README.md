# Modelo de relatório do aluno

Conteúdo do pacote:

- `modelo_relatorio_aluno.tex` — arquivo base a ser editado
- `unb.png` — logo usado na capa, mantenha na mesma pasta do `.tex`
- `modelo_relatorio_aluno.pdf` — exemplo já compilado

## Como usar

1. Abra o arquivo e preencha os dados no bloco de comandos, `\pratica`, `\aluno`, `\matricula`, `\turma`.
2. Escreva o conteúdo nas seções:
   - Introdução
   - Metodologia
   - Resultados
   - Conclusão
   - Referências
3. Compile com:

```bash
pdflatex modelo_relatorio_aluno.tex
```

Compile duas vezes para que sumário e referências fiquem corretos. Se preferir não instalar LaTeX, o mesmo arquivo pode ser compilado no Overleaf: crie um projeto em branco e envie os três arquivos deste pacote.

## Entrega

Envie apenas o PDF pelo SIGAA, um relatório por prática.
